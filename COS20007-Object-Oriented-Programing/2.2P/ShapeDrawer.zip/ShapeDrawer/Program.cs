using System;
using SplashKitSDK;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Program
{
    public static void Main()
    {
        new Window("My Shape", 800, 600);
        shapedrawer.Shape myShape = new shapedrawer.Shape();
        do
        {
            SplashKit.ProcessEvents();
            SplashKit.ClearScreen();
            myShape.Draw();
            if (SplashKit.MouseClicked(MouseButton.LeftButton)) {
                myShape.X = SplashKit.MouseX();
                myShape.Y = SplashKit.MouseY();

            }
            Point2D mouseposition = SplashKit.MousePosition();

            if (myShape.IsAt(mouseposition) && SplashKit.KeyTyped(KeyCode.SpaceKey))
                myShape.color = SplashKit.RandomRGBColor(255);
            SplashKit.RefreshScreen();
        }
        while (!SplashKit.WindowCloseRequested("My Shape"));
    }
}
