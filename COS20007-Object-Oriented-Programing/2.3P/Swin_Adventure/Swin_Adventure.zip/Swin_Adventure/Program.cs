﻿using System;
using NUnit.Framework;

namespace Swin_Adventure
{
    internal class Program
    {
        static void Main(string[] args)
        {
          
        }
    }
}
