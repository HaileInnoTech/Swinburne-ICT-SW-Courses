﻿using System;
using NUnit.Framework;

namespace Swin_Adventure
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
