using NUnit.Framework;
using Swin_Adventure;
namespace Test_Interation2
{
    public class Test_Item
    {
        
        [Test]
        public void Test_Item_Identifiable()
        {
            I2_Item potion = new I2_Item(new string[] { "potion" }, "potion", "energy potion");
            Assert.IsTrue(potion.AreYou("Potion"));
        }
        [Test()]
        public void ShortDescription()
        {
            I2_Item potion = new I2_Item(new string[] { "potion" }, "potion", "energy potion");

            Assert.AreEqual(potion.short_Description, "potion (potion)");

        }


        [Test()]
        public void LongDescription()
        {
            I2_Item potion = new I2_Item(new string[] { "potion" }, "potion", "energy potion");
            Assert.AreEqual(potion.full_Description, "energy potion");
        }
    }
}